---
name: 📄 Documentation
about: Suggest an improvement to our documentation
labels: type/docs
---

### Documentation Feedback

Provide a brief summary of what you would like to see changed in our documentation.

Feel free to provide any suggestions of content or examples you’d like us to include.

**Affected documentation page:** Insert a link to the affected page


