const MeetingSettingKeys = {
  micEnabled: "micEnabled",
  videoEnabled: "videoEnabled",
  resolution: "resolution",
  enableFirefoxSimulcast: "enableFirefoxSimulcast"
};

export default MeetingSettingKeys;
