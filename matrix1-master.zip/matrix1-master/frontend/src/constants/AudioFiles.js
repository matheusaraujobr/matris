const soundRoot = "/mp3";

const AudioFiles = {
  inviteNotification: `${soundRoot}/invite_sound.mp3`,
};

export default AudioFiles;
