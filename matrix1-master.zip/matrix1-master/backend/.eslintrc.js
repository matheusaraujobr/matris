module.exports = {
  env: {
    node: true,
    jest: true,
  },
  rules: {
    "no-unused-expressions": ["off"]
  }
};
